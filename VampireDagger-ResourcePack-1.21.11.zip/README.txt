Vampire Dagger Resource Pack — Minecraft Java 1.21.11

Install:
1. Put this ZIP into your Minecraft resourcepacks folder.
2. Enable it under Options > Resource Packs.

Important compatibility note:
This pack uses the 1.21.11 item-definition format and selects the custom look
when the Netherite Sword has CustomModelData value 10001.

The server-side item/plugin must assign CustomModelData 10001 to the dagger.
The previously supplied plugin was not verified to do that, so the custom look
may not appear until the plugin item creation code is updated accordingly.

This is a Java Edition pack for 1.21.11. It is not a Bedrock pack.
